import { Component } from '@angular/core';
import {
  NavController,
  AlertController,
  MenuController,
  ToastController,
  PopoverController,
  ModalController,LoadingController  } from '@ionic/angular';
import { Routes, RouterModule,NavigationExtras  } from '@angular/router';
// Modals
import { SearchFilterPage } from '../../pages/modal/search-filter/search-filter.page';
import { ImagePage } from './../modal/image/image.page';
// Call notifications test by Popover and Custom Component.
import { NotificationsComponent } from './../../components/notifications/notifications.component';
import { AssumptionsPage } from '../assumptions/assumptions.page';

@Component({
  selector: 'app-home-results',
  templateUrl: './home-results.page.html',
  styleUrls: ['./home-results.page.scss']
})
export class HomeResultsPage {
  searchKey = '';
  yourLocation = '123 Test Street';
  themeCover = 'assets/img/ionic4-Start-Theme-cover.jpg';
    
    public currency_preference: string                          = 'USD';
    public total_number_of_items_to_be_tagged: any              = '250000';
    public total_items_on_the_floor: string                     = '40000';
    public total_items_in_the_back_room: string                 = '10000';
    public average_selling_price_per_item: string               = '7';
    public sold_items_number: string                            = '168069';    
    public annual_revenue_per_store: string                     = '1009286';
    public size_of_store: string                                = '7130';
    public number_of_stores: string                             = '550';
    //public tax_rate: string                                     = '21';
    public labor_cost_hour: string                              = '0.60';    
    public hours_spent_per_store_month: string                  = '150';
    public no_of_items_on_the_floor: string                     = '50000';
    public no_of_items_counted_per_person_store_hour: string    = '500';
    public back_to_front_replenishment: string                  = '60';
    public staff_enquiry_cost: string                           = '117'; 
    public staff_enquiry_time_to_sale_one_apparel: string       = '0.25';   
    public security_surveillance_cost: string                   = '30';
    public inventory: string                                    = '50464';
    public mark_down_percentage: string                         = '20';
    public failed_sales: string                                 = '4205';
  
    constructor(
        public navCtrl: NavController,
        public menuCtrl: MenuController,
        public popoverCtrl: PopoverController,
        public alertCtrl: AlertController,
        public modalCtrl: ModalController,
        public toastCtrl: ToastController,
        public loadingController: LoadingController
  ) {
  }

  ionViewWillEnter() {
    this.menuCtrl.enable(true);
  }

  settings() {
    this.navCtrl.navigateForward('settings');
  }

  async alertLocation() {
    const changeLocation = await this.alertCtrl.create({
      header: 'Change Location',
      message: 'Type your Address.',
      inputs: [
        {
          name: 'location',
          placeholder: 'Enter your new Location',
          type: 'text'
        },
      ],
      buttons: [
        {
          text: 'Cancel',
          handler: data => {
            console.log('Cancel clicked');
          }
        },
        {
          text: 'Change',
          handler: async (data) => {
            console.log('Change clicked', data);
            this.yourLocation = data.location;
            const toast = await this.toastCtrl.create({
              message: 'Location was change successfully',
              duration: 3000,
              position: 'top',
              closeButtonText: 'OK',
              showCloseButton: true
            });

            toast.present();
          }
        }
      ]
    });
    changeLocation.present();
  }
  
  doEstimate() {
      this.loadingController.create({
            message: 'Estimation in progress....',
            duration: 1000
       }).then((res) => {
            res.present();
       });
      let navigationExtras: NavigationExtras = {
        queryParams: {
            currency_preference                         : this.currency_preference,
            total_number_of_items_to_be_tagged          : this.total_number_of_items_to_be_tagged,
            total_items_on_the_floor                    : this.total_items_on_the_floor,
            total_items_in_the_back_room                : this.total_items_in_the_back_room,
            average_selling_price_per_item              : this.average_selling_price_per_item,
            sold_items_number                           : this.sold_items_number,
            annual_revenue_per_store                    : this.annual_revenue_per_store,
            size_of_store                               : this.size_of_store,
            number_of_stores                            : this.number_of_stores,
           // tax_rate                                    : this.tax_rate,
            labor_cost_hour                             : this.labor_cost_hour,
            hours_spent_per_store_month                 : this.hours_spent_per_store_month,
            no_of_items_on_the_floor                    : this.no_of_items_on_the_floor,
            no_of_items_counted_per_person_store_hour   : this.no_of_items_counted_per_person_store_hour,
            back_to_front_replenishment                 : this.back_to_front_replenishment,
            staff_enquiry_cost                          : this.staff_enquiry_cost,
            staff_enquiry_time_to_sale_one_apparel      : this.staff_enquiry_time_to_sale_one_apparel,
            security_surveillance_cost                  : this.security_surveillance_cost,
            inventory                                   : this.inventory,
            mark_down_percentage                        : this.mark_down_percentage,
            failed_sales                                : this.failed_sales            
    }
};
      this.navCtrl.navigateForward(['assumptions'], navigationExtras);
  }
    
  async searchFilter () {
    const modal = await this.modalCtrl.create({
      component: SearchFilterPage
    });
    return await modal.present();
  }

  async presentImage(image: any) {
    const modal = await this.modalCtrl.create({
      component: ImagePage,
      componentProps: { value: image }
    });
    return await modal.present();
  }

  async notifications(ev: any) {
    const popover = await this.popoverCtrl.create({
      component: NotificationsComponent,
      event: ev,
      animated: true,
      showBackdrop: true
    });
    return await popover.present();
  }

}
