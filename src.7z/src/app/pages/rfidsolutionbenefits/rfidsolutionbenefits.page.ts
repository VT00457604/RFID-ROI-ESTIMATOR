import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute} from "@angular/router";
import { NavController, Platform, IonSlides } from '@ionic/angular';
import { Routes, RouterModule,NavigationExtras  } from '@angular/router';
import * as HighCharts from 'highcharts';
//declare var require: any;
//var Highcharts = require('highcharts');
//require('highcharts/modules/exporting')(Highcharts);

import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';

import { EmailComposer } from '@ionic-native/email-composer/ngx';

import { LoadingController } from '@ionic/angular';
@Component({
  selector: 'app-rfidsolutionbenefits',
  templateUrl: './rfidsolutionbenefits.page.html',
  styleUrls: ['./rfidsolutionbenefits.page.scss'],
})
export class RfidsolutionbenefitsPage implements OnInit {
    pdfObj = null;        
    currency_preference                         : any;
    other_currency_to_inr                       : any;
    total_number_of_items_to_be_tagged          : any;
    total_items_on_the_floor                    : any;
    total_items_in_the_back_room                : any;
    average_selling_price_per_item              : any;
    sold_items_number                           : any; 
    annual_revenue_per_store                    : any;
    size_of_store                               : any;
    number_of_stores                            : any;
    total_revenue_sqft_store                    : any;
    total_revenue                               : any;
    //tax_rate                                    : any;
    labor_cost_hour                             : any;
    hours_spent_per_store_month                 : any;
    reduction_labour_hours_after_implementation : any;
    reduction_labour_receiving_cost_per_store   : any;
    reduction_labour_cost_after_implementation  : any;
    no_of_items_on_the_floor                    : any;
    no_of_items_counted_per_person_store_hour   : any;
    total_no_of_man_hours_for_complete_inventory: any;
    total_no_man_hours_for_complete_inventory_after: any;
    total_cost_store_month                      : any;
    total_cost_store_month_after                : any;
    back_to_front_replenishment                 : any;
    back_to_front_replenishment_after           : any;
    cost_per_store_month                        : any;
    cost_per_store_month_after                  : any;
    total_cost_for_stock_keeping_time           : any;
    total_cost_for_stock_keeping_time_after     : any;
    staff_enquiry_cost                          : any;
    staff_enquiry_time_to_sale_one_apparel: any;
    staff_enquiry_cost_after                    : any;
    staff_enquiry_cost_per_store_month          : any;
    staff_enquiry_cost_per_store_month_after    : any;
    security_surveillance_cost                  : any;
    security_surveillance_cost_after            : any;
    security_surveillance_cost_per_store_month  : any;
    security_surveillance_cost_per_store_month_after: any;
    total_labor_per_store_month                 : any;
    total_labor_per_store_month_after           : any;
    labor_saving_cost                           : any;
    shoplifting                                 : any;
    shoplifting_after                           : any;
    employee_theft                              : any;
    employee_theft_after                        : any;
    paperwork_errors                            : any;
    paperwork_errors_after                      : any;
    supplier_fraud                              : any;
    supplier_fraud_after                        : any;
    others                                      : any;
    others_after                                : any;
    total_shrinkage_store_month                 : any;
    total_shrinkage_store_month_after           : any;
    reduction_due_to_rfid_after                 : any;
    net_benefit_of_shrinkage_reduction_after    : any;
    sales_per_month_store                       : any;
    sales_increase_due_to_better_product_mix    : any;
    sales_increase_due_to_more_variants_omni_channel: any;
    sales_increase_due_to_ability_locate_stocks : any;
    total_shrinkage_as_age_of_sale              : any;
    total_shrinkage_as_age_of_sale_after        : any;
    per_revenue_increase_from_incremental_sales : any;
    revenue_increase_from_incremental_sales     : any;
    new_revenue                                 : any;
    new_revenue_sqft                            : any;
    increase_in_revenue_sqft                    : any;
    inventory                                   : any;
    inventory_after                             : any;
    mark_down_percentage                        : any;
    mark_down_percentage_after                  : any;
    mark_down_percentage_reduction_value        : any;
    failed_sales                                : any;
    failed_sales_after                          : any;
    improvement_in_inventory_trun_over          : any;
    total_benefit_per_store_month               : any;
    total_benefit_per_store_year                : any;
    total_stocks_returns                        : any;    
    rfid_pos_station_readers_cost_per_unit      : any;
    rfid_pos_station_readers_units              : any;
    rfid_pos_station_readers_total              : any;
    hand_held_readers_for_scanning_cost_per_unit: any;
    hand_held_readers_for_scanning_units        : any;
    hand_held_readers_for_scanning_total        : any;
    hand_held_scanner_software_cost_per_unit    : any;
    hand_held_scanner_software_units            : any;
    hand_held_scanner_software_total            : any;
    shell_used_for_grn_movement_cost_per_unit   : any;
    shell_used_for_grn_movement_units           : any;
    shell_used_for_grn_movement_total           : any;
    application_software_cost_per_unit          : any;
    application_software_units                  : any;
    application_software_total                  : any;
    rfid_bulk_encoder_cost_per_unit             : any;
    rfid_bulk_encoder_units                     : any;
    rfid_bulk_encoder_total                     : any;
    tag_cost_inr_first                          : any;
    tag_cost_other_currency_first               : any;
    tag_cost_usage_first                        : any;
    tag_cost_inr_second                         : any;
    tag_cost_other_currency_second              : any;
    tag_cost_usage_second                       : any;
    tag_cost_inr_third                          : any;
    tag_cost_other_currency_third               : any;
    tag_cost_usage_third                        : any;
    cost_of_tagging_first                       : any;
    cost_of_tagging_second                      : any;
    cost_of_tagging_third                       : any;
    cost_of_tagging_total                       : any;
    investment_in_rfid_per_store                : any;    
    implementation_cost                         : any;
    back_end_server_integration_erp             : any;
    training_installation                       : any;
    opex                                        : any;
    tag_replenish                               : any;
    amc_of_equipments                           : any;
    total_investment_in_rfid_per_store_per_year_first : any;
    total_investment_in_rfid_per_store_per_year : any;
    payback_period_in_months                    : any;
    benefits_attributable_to_rfid_year1         : any;
    benefits_attributable_to_rfid_year2         : any;
    benefits_attributable_to_rfid_year3         : any;
    total_cost_attributable_to_rfid_year1       : any;
    total_cost_attributable_to_rfid_year2       : any;
    total_cost_attributable_to_rfid_year3       : any;
    net_benefits_per_store_year1                : any;
    net_benefits_per_store_year2                : any;
    net_benefits_per_store_year3                : any;
    chain_wide_net_benefits_year1               : any;
    chain_wide_net_benefits_year2               : any;
    chain_wide_net_benefits_year3               : any;
    total_chain_wide_investment_other_currency  : any;
    total_chain_wide_investment_in_inr          : any;
    total_chain_wide_net_benefits_other_currency: any;
    total_chain_wide_net_benefits_in_inr        : any;
    sold_items_data                             : any;
    size_of_the_store_in_sqft                   : any;
    no_of_sku                                   : any;
    no_of_units_sold_month                      : any;
    no_of_units_sold_year                       : any;
    total_manpower_resources                    : any;
    total_cost_of_implementation_store_other_currency : any;
    total_cost_of_implementation_store_in_inr   : any;
    recurring_cost_per_year_other_currency      : any;
    recurring_cost_per_year_in_inr              : any;
    reduction_in_shrinkage                      : any;
    reduction_in_shoplifting                    : any;
    reduction_in_employee_theft                 : any;
    reduction_in_paperwork_theft                : any;
    reduction_in_supplier_fraud                 : any;
    reduction_in_others                         : any;
    new_shrinkage_per_of_sales                  : any;
    reduction_in_labour_hours                   : any;
    reduction_in_staff_enquiry_cost             : any;
    reduction_in_stock_keeping_time             : any;
    reduction_in_security_survelliance_cost     : any;    
    reduction_in_inventory_turn_over            : any;
    reduction_in_failed_sales                   : any;
    reduction_in_leaner_inventory               : any;
    reduction_in_obscelence_cost_mark_down_cost : any;
    shoplifting_desired_status         : any;
    myChart                                     : any;
    employee_theft_desired_status      : any;
    paperwork_errors_desired_status    : any;
    supplier_fraud_desired_status      : any;
    others_desired_status              : any;
    
    total_cost_attributable_to_rfid_for_three_years: any;
    benefits_attributable_to_rfid_for_three_years: any;
    
    
    
    
    slideOpts1 = {
        initialSlide: 0,
        speed: 400,
        loop: true,
        slidesPerView: 1,
        autoplay: false
    };
    
  constructor(private route: ActivatedRoute,public navCtrl: NavController, private plt: Platform, private file: File, private fileOpener: FileOpener, private emailComposer: EmailComposer,public loadingController: LoadingController) { }


  ngOnInit() {
        this.loadingController.create({
            message: 'Loading...RFID Benefits Solutions....',
            duration: 3000
       }).then((res) => {
            res.present();
       });
       this.route.queryParams.subscribe(params => {
        this.currency_preference                            = params["currency_preference"];
         if(this.currency_preference === 'USD'){
             this.other_currency_to_inr                     = "69.05";
         } else if(this.currency_preference === 'INR'){
              this.other_currency_to_inr                     = "1";
         } else if(this.currency_preference === 'EUR'){
              this.other_currency_to_inr                     = "76.99";
         } else if(this.currency_preference === 'POUND'){
              this.other_currency_to_inr                     = "85.96";
         } else if(this.currency_preference === 'AED'){
              this.other_currency_to_inr                     = "18.79";
         } else if(this.currency_preference === 'KD'){
              this.other_currency_to_inr                     = "183.14";
         }
        
        this.total_number_of_items_to_be_tagged             = params["total_number_of_items_to_be_tagged"];
        this.total_items_on_the_floor                       = params["total_items_on_the_floor"];
        this.total_items_in_the_back_room                   = params["total_items_in_the_back_room"];
        
        this.total_stocks_returns                           = parseInt(this.total_number_of_items_to_be_tagged)/(parseInt(this.total_items_on_the_floor) + parseInt(this.total_items_in_the_back_room));
        
        this.sold_items_number                              = params["sold_items_number"];
        this.average_selling_price_per_item                 = params["average_selling_price_per_item"];
        
        
        this.annual_revenue_per_store                       = Math.round(this.average_selling_price_per_item * this.sold_items_number);
        
        this.size_of_store                                  = params["size_of_store"];
        this.number_of_stores                               = params["number_of_stores"];
        
        this.total_revenue_sqft_store                       = Math.round(parseInt(this.annual_revenue_per_store) / parseInt(this.size_of_store));
        this.total_revenue                                  = Math.round(parseInt(this.annual_revenue_per_store) * parseInt(this.number_of_stores));
        
        //this.tax_rate                                       = params["tax_rate');
        this.labor_cost_hour                                = params["labor_cost_hour"];
        this.hours_spent_per_store_month                    = params["hours_spent_per_store_month"];
        
        this.reduction_labour_hours_after_implementation    = this.hours_spent_per_store_month * 0.3;
        this.reduction_labour_receiving_cost_per_store      = this.hours_spent_per_store_month * this.labor_cost_hour;
        this.reduction_labour_cost_after_implementation     = this.reduction_labour_hours_after_implementation * this.labor_cost_hour;
        
         
        this.no_of_items_on_the_floor                       = params["no_of_items_on_the_floor"];
        this.no_of_items_counted_per_person_store_hour      = params["no_of_items_counted_per_person_store_hour"];
        
        this.total_no_of_man_hours_for_complete_inventory   = this.no_of_items_on_the_floor/this.no_of_items_counted_per_person_store_hour;
        
        this.total_no_man_hours_for_complete_inventory_after= Math.round(this.no_of_items_on_the_floor/15000);
        
        this.total_cost_store_month                         = this.total_no_of_man_hours_for_complete_inventory * this.labor_cost_hour;
        
        this.total_cost_store_month_after                   = Math.round(this.total_no_man_hours_for_complete_inventory_after * this.labor_cost_hour);
        
        this.back_to_front_replenishment                    = params["back_to_front_replenishment"];
        
        this.back_to_front_replenishment_after              = 0.5 * this.back_to_front_replenishment;
        
        this.cost_per_store_month                           = this.back_to_front_replenishment * this.labor_cost_hour;
        
        this.cost_per_store_month_after                     = this.back_to_front_replenishment_after * this.labor_cost_hour;
        
        this.total_cost_for_stock_keeping_time              = this.reduction_labour_receiving_cost_per_store + this.total_cost_store_month + this.cost_per_store_month;
        
        this.total_cost_for_stock_keeping_time_after        = this.reduction_labour_cost_after_implementation + this.total_cost_store_month_after + this.cost_per_store_month_after;
        
        this.staff_enquiry_cost                             = params["staff_enquiry_cost"];
        
        this.staff_enquiry_cost_after                       = Math.round((this.sold_items_number / 12 / 30) * 0.16);
        
        this.staff_enquiry_cost_per_store_month             = Math.round(this.staff_enquiry_cost * this.labor_cost_hour);
        
        this.staff_enquiry_cost_per_store_month_after       = Math.round(this.staff_enquiry_cost_after * this.labor_cost_hour);
        
        this.security_surveillance_cost                     = params["security_surveillance_cost"];
        
        this.security_surveillance_cost_after               = 0.7 * 30;
        
        this.security_surveillance_cost_per_store_month     = Math.round(this.security_surveillance_cost * this.labor_cost_hour);
        
        this.security_surveillance_cost_per_store_month_after = Math.round(this.security_surveillance_cost_after * this.labor_cost_hour);
        
        this.total_labor_per_store_month                    = this.reduction_labour_receiving_cost_per_store + this.total_cost_store_month + this.cost_per_store_month + this.staff_enquiry_cost_per_store_month + this.security_surveillance_cost_per_store_month;
        
        this.total_labor_per_store_month_after              = this.reduction_labour_cost_after_implementation + this.total_cost_store_month_after + this.cost_per_store_month_after + this.staff_enquiry_cost_per_store_month_after + this.security_surveillance_cost_per_store_month_after;
        
        this.labor_saving_cost                              = this.total_labor_per_store_month - this.total_labor_per_store_month_after;
         
        this.shoplifting                                    = ((params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12 * (params["shoplifting_current_status"]/100)).toFixed(2);
        
        this.shoplifting_desired_status                     = (params["shoplifting_current_status"] / 100) * (1 - (params["shoplifting_solution_benefits"] / 100));
           
        this.shoplifting_after                              = (this.shoplifting_desired_status * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.employee_theft                                 = ((params["employee_theft_current_status"]/100) * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.employee_theft_desired_status                  = (params["employee_theft_current_status"] / 100) * (1 - (params["employee_theft_solution_benefits"] / 100));
        
        this.employee_theft_after                           = (this.employee_theft_desired_status * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.paperwork_errors                               = ((params["paperwork_errors_current_status"]/100) * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.paperwork_errors_desired_status                = (params["paperwork_errors_current_status"] / 100) * (1 - (params["paperwork_errors_solution_benefits"] / 100));
        
        this.paperwork_errors_after                         = (this.paperwork_errors_desired_status * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.supplier_fraud                                 = ((params["supplier_fraud_current_status"]/100) * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.supplier_fraud_desired_status                  = (params["supplier_fraud_current_status"] / 100) * (1 - (params["supplier_fraud_solution_benefits"] / 100));
        
        this.supplier_fraud_after                           = (this.supplier_fraud_desired_status * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.others                                         = ((params["others_current_status"]/100) * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
        
        this.others_desired_status                          = (params["others_current_status"] / 100) * (1 - (params["others_solution_benefits"] / 100));
           
        this.others_after                                   = (this.others_desired_status * (params["total_shrinkage_current_status"]/100) * this.annual_revenue_per_store / 12).toFixed(2);
               
        this.total_shrinkage_store_month                    = parseInt(this.shoplifting) + parseInt(this.employee_theft) + parseInt(this.paperwork_errors) + parseInt(this.supplier_fraud) + parseInt(this.others);
        
        this.total_shrinkage_store_month_after              = parseInt(this.shoplifting_after) + parseInt(this.employee_theft_after) + parseInt(this.paperwork_errors_after) + parseInt(this.supplier_fraud_after) + parseInt(this.others_after);
        
        this.total_shrinkage_as_age_of_sale                 = params["total_shrinkage_current_status"]/100;
        
        this.total_shrinkage_as_age_of_sale_after           = (params["total_shrinkage_current_status"]/100) * (this.shoplifting_desired_status + this.employee_theft_desired_status + this.paperwork_errors_desired_status + this.supplier_fraud_desired_status + this.others_desired_status);
        
        this.reduction_due_to_rfid_after                    = this.total_shrinkage_as_age_of_sale - this.total_shrinkage_as_age_of_sale_after;
           
        this.net_benefit_of_shrinkage_reduction_after       = this.total_shrinkage_store_month - this.total_shrinkage_store_month_after;
        
        this.sales_per_month_store                          = Math.round(this.total_revenue / (12 * this.number_of_stores));
        
        this.sales_increase_due_to_better_product_mix       = params["sales_increase_due_to_better_product_mix"];
        
        this.sales_increase_due_to_more_variants_omni_channel= params["sales_increase_due_to_more_variants_omni_channel"];
        
        this.sales_increase_due_to_ability_locate_stocks    = params["sales_increase_due_to_ability_locate_stocks"];
        
        this.per_revenue_increase_from_incremental_sales    = parseInt(this.sales_increase_due_to_better_product_mix) + parseInt(this.sales_increase_due_to_more_variants_omni_channel) +  parseInt(this.sales_increase_due_to_ability_locate_stocks);
         
        this.revenue_increase_from_incremental_sales        = this.sales_per_month_store * (this.per_revenue_increase_from_incremental_sales/100);
        
        this.new_revenue                                    = this.sales_per_month_store + this.revenue_increase_from_incremental_sales;
        
        this.new_revenue_sqft                               = (this.new_revenue * 12 / this.size_of_store).toFixed(2);
        
        this.increase_in_revenue_sqft                       = (((this.new_revenue_sqft - this.total_revenue_sqft_store)/this.total_revenue_sqft_store) * 100).toFixed(2);
        
        this.inventory                                      = params["inventory"];
        
        this.inventory_after                                = (this.inventory * 0.95).toFixed(2);
        
        this.mark_down_percentage                           = params["mark_down_percentage"];
        
        this.mark_down_percentage_after                     = 19.90;
        
        this.mark_down_percentage_reduction_value           = (((this.mark_down_percentage - this.mark_down_percentage_after) * this.annual_revenue_per_store)/100).toFixed(2);
        
        this.failed_sales                                   = params["failed_sales"];
        
        this.failed_sales_after                             = this.failed_sales * 0.9;
        
        this.improvement_in_inventory_trun_over             = (parseInt(this.inventory) - parseInt(this.inventory_after)) + parseInt(this.mark_down_percentage_reduction_value) + (parseInt(this.failed_sales) - parseInt(this.failed_sales_after));
        
        this.total_benefit_per_store_month                  = parseInt(this.labor_saving_cost) + parseInt(this.net_benefit_of_shrinkage_reduction_after) + parseInt(this.improvement_in_inventory_trun_over);
   
        this.total_benefit_per_store_year                   =  this.total_benefit_per_store_month * 12;
        
        this.rfid_pos_station_readers_cost_per_unit         = 1339.29;
        
        this.rfid_pos_station_readers_units                 = 4;
        
        this.rfid_pos_station_readers_total                 =  Math.round(this.rfid_pos_station_readers_cost_per_unit * this.rfid_pos_station_readers_units);
        
        this.hand_held_readers_for_scanning_cost_per_unit   = 2678.57;
        
        this.hand_held_readers_for_scanning_units           = 2;
        
        this.hand_held_readers_for_scanning_total           =  Math.round(this.hand_held_readers_for_scanning_cost_per_unit * this.hand_held_readers_for_scanning_units);
        
        this.hand_held_scanner_software_cost_per_unit       = 600;
        
        this.hand_held_scanner_software_units               = 2;
        
        this.hand_held_scanner_software_total               =  Math.round(this.hand_held_scanner_software_cost_per_unit * this.hand_held_scanner_software_units);
        
        this.shell_used_for_grn_movement_cost_per_unit      = 2000;
        
        this.shell_used_for_grn_movement_units              = 1;
        
        this.shell_used_for_grn_movement_total              =  Math.round(this.shell_used_for_grn_movement_cost_per_unit * this.shell_used_for_grn_movement_units);
        
        this.application_software_cost_per_unit             = 1500;
        
        this.application_software_units                     = 1;
        
        this.application_software_total                     =  Math.round(this.application_software_cost_per_unit * this.application_software_units);
        
        this.rfid_bulk_encoder_cost_per_unit                = 1500;
        
        this.rfid_bulk_encoder_units                        = 1;
        
        this.rfid_bulk_encoder_total                        =  Math.round(this.rfid_bulk_encoder_cost_per_unit * this.rfid_bulk_encoder_units);
        
        this.tag_cost_inr_first                             = 18;
        
        this.tag_cost_other_currency_first                  = (this.tag_cost_inr_first / this.other_currency_to_inr).toFixed(2);
        
        this.tag_cost_inr_second                            = 5;
        
        this.tag_cost_other_currency_second                 = (this.tag_cost_inr_second / this.other_currency_to_inr).toFixed(2);
        
        this.tag_cost_inr_third                             = 7;
        
        this.tag_cost_other_currency_third                  = (this.tag_cost_inr_third / this.other_currency_to_inr).toFixed(2);
        
        this.tag_cost_usage_first                           = 95;
        
        this.tag_cost_usage_second                          = 5;
        
        this.tag_cost_usage_third                           = 0;
        
        this.cost_of_tagging_first                          = ((this.tag_cost_usage_first/100) * this.tag_cost_other_currency_first *  this.total_number_of_items_to_be_tagged * 0.20).toFixed(2);
        
        this.cost_of_tagging_second                         = ((this.tag_cost_usage_second/100) * this.tag_cost_other_currency_second *  this.total_number_of_items_to_be_tagged * 0.1).toFixed(2);
        
        this.cost_of_tagging_third                          = ((this.tag_cost_usage_third/100) * this.tag_cost_other_currency_third *  this.total_number_of_items_to_be_tagged * 0.15).toFixed(2);
        
        this.cost_of_tagging_total                          = parseInt(this.cost_of_tagging_first) + parseInt(this.cost_of_tagging_second) + parseInt(this.cost_of_tagging_third);
    
        this.investment_in_rfid_per_store                   =  parseInt(this.cost_of_tagging_total) +  parseInt(this.rfid_pos_station_readers_total) + parseInt(this.hand_held_readers_for_scanning_total) + parseInt(this.hand_held_scanner_software_total) + parseInt(this.shell_used_for_grn_movement_total) + parseInt(this.application_software_total) + parseInt(this.rfid_bulk_encoder_total) ;
    
        this.implementation_cost                            = 1000;
        
        this.back_end_server_integration_erp                = 50;
        
        this.training_installation                          = 500;
        
        this.opex                                           = 1500;
        
        this.tag_replenish                                  = 0.03 * this.cost_of_tagging_total;
        
        this.amc_of_equipments                              = 125 * 12;
        
        this.total_investment_in_rfid_per_store_per_year_first  = parseInt(this.implementation_cost) + parseInt(this.back_end_server_integration_erp) + parseInt(this.training_installation) + parseInt(this.opex) + parseInt(this.tag_replenish) + parseInt(this.amc_of_equipments);
    
        this.total_investment_in_rfid_per_store_per_year    =  parseInt(this.investment_in_rfid_per_store) + parseInt(this.total_investment_in_rfid_per_store_per_year_first);
   
        this.payback_period_in_months                       = Math.round(this.total_investment_in_rfid_per_store_per_year / this.total_benefit_per_store_month);
        
        this.benefits_attributable_to_rfid_year1            = this.total_benefit_per_store_year;
        
        this.benefits_attributable_to_rfid_year2            = Math.round((this.benefits_attributable_to_rfid_year1 * 0.05) + this.benefits_attributable_to_rfid_year1);
        
        this.benefits_attributable_to_rfid_year3            = Math.round((this.benefits_attributable_to_rfid_year2 * 0.05) + this.benefits_attributable_to_rfid_year2);
        
        this.total_cost_attributable_to_rfid_year1          = this.total_investment_in_rfid_per_store_per_year;
        
        this.total_cost_attributable_to_rfid_year2          = parseInt(this.hand_held_scanner_software_total) + parseInt(this.application_software_total) + parseInt(this.opex) + parseInt(this.tag_replenish) + parseInt(this.amc_of_equipments);
        
        this.total_cost_attributable_to_rfid_year3          = parseInt(this.hand_held_scanner_software_total) + parseInt(this.application_software_total) + parseInt(this.opex) + parseInt(this.tag_replenish) + parseInt(this.amc_of_equipments);
    
        this.net_benefits_per_store_year1                   = this.benefits_attributable_to_rfid_year1 - this.total_cost_attributable_to_rfid_year1;
        
        this.net_benefits_per_store_year2                   = this.benefits_attributable_to_rfid_year2 - this.total_cost_attributable_to_rfid_year2;
        
        this.net_benefits_per_store_year3                   = this.benefits_attributable_to_rfid_year3 - this.total_cost_attributable_to_rfid_year3;
        
        this.chain_wide_net_benefits_year1                  = this.net_benefits_per_store_year1 * this.number_of_stores;
        
        this.chain_wide_net_benefits_year2                  = this.net_benefits_per_store_year2 * this.number_of_stores;
        
        this.chain_wide_net_benefits_year3                  = this.net_benefits_per_store_year3 * this.number_of_stores;
         
        this.total_cost_attributable_to_rfid_for_three_years = parseInt(this.total_cost_attributable_to_rfid_year1) + parseInt(this.total_cost_attributable_to_rfid_year2) + parseInt(this.total_cost_attributable_to_rfid_year3);
        
        this.benefits_attributable_to_rfid_for_three_years =  parseInt(this.benefits_attributable_to_rfid_year1) + parseInt(this.benefits_attributable_to_rfid_year2) + parseInt(this.benefits_attributable_to_rfid_year3);
         
        this.total_chain_wide_investment_other_currency    = (parseInt(this.total_cost_attributable_to_rfid_year1) + parseInt(this.total_cost_attributable_to_rfid_year2) + parseInt(this.total_cost_attributable_to_rfid_year3)) * this.number_of_stores;
    
        this.total_chain_wide_investment_in_inr            = this.total_chain_wide_investment_other_currency * this.other_currency_to_inr;
        
        this.total_chain_wide_net_benefits_other_currency   = parseInt(this.chain_wide_net_benefits_year1) + parseInt(this.chain_wide_net_benefits_year2) + parseInt(this.chain_wide_net_benefits_year3);
    
        this.total_chain_wide_net_benefits_in_inr           = this.total_chain_wide_net_benefits_other_currency * this.other_currency_to_inr;
    
        this.sold_items_data                                = this.average_selling_price_per_item * this.other_currency_to_inr;
        
        this.size_of_the_store_in_sqft                      = this.size_of_store;
        
        this.no_of_sku                                      = 1000;
        
        this.no_of_units_sold_month                         = 10000 +" - "+20000;
        
        this.no_of_units_sold_year                          = 168069;
        
        this.total_manpower_resources                       = 25;
        
        this.total_cost_of_implementation_store_other_currency = this.total_investment_in_rfid_per_store_per_year;
        
        this.total_cost_of_implementation_store_in_inr      = this.total_cost_of_implementation_store_other_currency * this.other_currency_to_inr;;
        
        this.recurring_cost_per_year_other_currency         = this.total_cost_attributable_to_rfid_year2;
        
        this.recurring_cost_per_year_in_inr                 = this.total_cost_attributable_to_rfid_year2 * this.other_currency_to_inr;
         
        this.reduction_in_shrinkage                         = ((this.total_shrinkage_as_age_of_sale - this.total_shrinkage_as_age_of_sale_after) * 100).toFixed(1) ;
         
        this.reduction_in_shoplifting                       = Math.round((((this.shoplifting - this.shoplifting_after)/this.shoplifting)) * 100);
         
        this.reduction_in_employee_theft                    = Math.round((((this.employee_theft - this.employee_theft_after)/this.employee_theft)) * 100);
         
        this.reduction_in_paperwork_theft                   = Math.round((((this.paperwork_errors - this.paperwork_errors_after)/this.paperwork_errors)) * 100);
         
        this.reduction_in_supplier_fraud                    = Math.round((((this.supplier_fraud - this.supplier_fraud_after)/this.supplier_fraud)) * 100);
    
        this.reduction_in_others                            = Math.round((((this.others - this.others_after)/this.others)) * 100);
         
        this.new_shrinkage_per_of_sales                     = this.total_shrinkage_as_age_of_sale_after;
         
        this.reduction_in_labour_hours                      = Math.round((this.labor_saving_cost  / this.total_labor_per_store_month) * 100 );
         
        this.reduction_in_staff_enquiry_cost                = Math.round((((this.staff_enquiry_cost_per_store_month - this.staff_enquiry_cost_per_store_month_after)/this.staff_enquiry_cost_per_store_month)) * 100); 
         
        this.reduction_in_stock_keeping_time                = Math.round((((this.total_cost_for_stock_keeping_time - this.total_cost_for_stock_keeping_time_after)/this.total_cost_for_stock_keeping_time)) * 100);
         
        this.reduction_in_security_survelliance_cost        = Math.round((((this.security_surveillance_cost_per_store_month - this.security_surveillance_cost_per_store_month_after)/this.security_surveillance_cost_per_store_month)) * 100);
         
        this.reduction_in_inventory_turn_over               = Math.round((this.improvement_in_inventory_trun_over / this.inventory) * 100);
         
        this.reduction_in_failed_sales                      = Math.round((1-(this.failed_sales_after / this.failed_sales)) * 100);
         
        this.reduction_in_leaner_inventory                  = Math.round(((this.inventory - this.inventory_after)/this.inventory) * 100);
        
        this.reduction_in_obscelence_cost_mark_down_cost    = (this.mark_down_percentage - this.mark_down_percentage_after).toFixed(2);
           
        
     
     });
  }
    
  executiveDashboard() {
        let navigationExtras: NavigationExtras = {
            queryParams: {
                currency_preference                         : this.currency_preference,
                reduction_in_shrinkage                      : this.reduction_in_shrinkage, 
                increase_in_revenue_sqft                    : this.increase_in_revenue_sqft,
                reduction_in_shoplifting                    : this.reduction_in_shoplifting, 
                reduction_in_employee_theft                 : this.reduction_in_employee_theft, 
                reduction_in_paperwork_theft                : this.reduction_in_paperwork_theft,
                reduction_in_supplier_fraud                 : this.reduction_in_supplier_fraud, 
                reduction_in_others                         : this.reduction_in_others,    
                new_shrinkage_per_of_sales                  : this.new_shrinkage_per_of_sales,  
                reduction_in_labour_hours                   : this.reduction_in_labour_hours,                     
                reduction_in_staff_enquiry_cost             : this.reduction_in_staff_enquiry_cost,               
                reduction_in_stock_keeping_time             : this.reduction_in_stock_keeping_time, 
                reduction_in_security_survelliance_cost     : this.reduction_in_security_survelliance_cost, 
                reduction_in_inventory_turn_over            : this.reduction_in_inventory_turn_over, 
                reduction_in_failed_sales                   : this.reduction_in_failed_sales,  
                reduction_in_leaner_inventory               : this.reduction_in_leaner_inventory,  
                reduction_in_obscelence_cost_mark_down_cost : this.reduction_in_obscelence_cost_mark_down_cost,
                total_cost_attributable_to_rfid_year1       : this.total_cost_attributable_to_rfid_year1,
                total_cost_attributable_to_rfid_year2       : this.total_cost_attributable_to_rfid_year2,
                total_cost_attributable_to_rfid_year3       : this.total_cost_attributable_to_rfid_year3,
                benefits_attributable_to_rfid_year1         : this.benefits_attributable_to_rfid_year1,
                benefits_attributable_to_rfid_year2         : this.benefits_attributable_to_rfid_year2,
                benefits_attributable_to_rfid_year3         : this.benefits_attributable_to_rfid_year3,
                other_currency_to_inr                       : this.other_currency_to_inr,
                total_cost_of_implementation_store_other_currency   : this.total_cost_of_implementation_store_other_currency,
                total_cost_of_implementation_store_in_inr   : this.total_cost_of_implementation_store_in_inr,
                recurring_cost_per_year_other_currency      : this.recurring_cost_per_year_other_currency,
                recurring_cost_per_year_in_inr              : this.recurring_cost_per_year_in_inr,
                total_chain_wide_investment_other_currency  : this.total_chain_wide_investment_other_currency,
                total_chain_wide_investment_in_inr          : this.total_chain_wide_investment_in_inr,
                total_chain_wide_net_benefits_other_currency: this.total_chain_wide_net_benefits_other_currency,
                total_chain_wide_net_benefits_in_inr        : this.total_chain_wide_net_benefits_in_inr,
                payback_period_in_months                    : this.payback_period_in_months,
                total_cost_attributable_to_rfid_for_three_years: this.total_cost_attributable_to_rfid_for_three_years,
                benefits_attributable_to_rfid_for_three_years: this.benefits_attributable_to_rfid_for_three_years,
                
                
            }
        };
        this.navCtrl.navigateForward(['executivedashboard'], navigationExtras);
   }
   
   ionViewWillEnter() {
        this.myChart = HighCharts.chart('container', {
            title: {
                text: 'COST - BENEFITS ANALYSIS'
            },
            xAxis: {
                categories: ['YEAR 1', 'YEAR 2', 'YEAR 3']
            },
            series: [{
                type: 'column',
                name: 'Total cost attributable to RFID<br> (In '+this.currency_preference+')',
                data: [this.total_cost_attributable_to_rfid_year1, this.total_cost_attributable_to_rfid_year2, this.total_cost_attributable_to_rfid_year3],
                color: HighCharts.getOptions().colors[0]
            }, {
                type: 'column',
                name: 'Total Benefits per store<br> (In '+this.currency_preference+')',
                data: [this.benefits_attributable_to_rfid_year1, this.benefits_attributable_to_rfid_year2 ,this.benefits_attributable_to_rfid_year3],
                color: HighCharts.getOptions().colors[3]
            }]
        });  
     }
    
    downloadPdf() {
        var docDefinition = {
          content: [
                    { text: 'Dashboard', style: [ 'header', 'anotherStyle' ] },
                    {
                        table: {
                            body: [
                                [{text: '', bold: true, style: 'tableHeader'}, {text: '(in '+ this.currency_preference+')', bold: true, style: 'tableHeader'}, {text: '(in INR) 1 '+ this.currency_preference+' = INR '+ this.other_currency_to_inr, bold: true, style: 'tableHeader'}],
                                ['Total cost of implementation/Store', this.total_cost_of_implementation_store_other_currency, this.total_cost_of_implementation_store_in_inr],
                                ['Recurring cost/Year', this.recurring_cost_per_year_other_currency, this.recurring_cost_per_year_in_inr],
                                ['Chain wide investment for the period of 3 years', this.total_chain_wide_investment_other_currency, this.total_chain_wide_investment_in_inr],
                                ['Chain wide Net Benefits for the period of 3 years', this.total_chain_wide_net_benefits_other_currency, this.total_chain_wide_net_benefits_in_inr],
                                ['Payback(in Months)', this.payback_period_in_months, this.payback_period_in_months],
                            ]
                        }
                    },
                    { text: 'Benefits of RFID Solutions', style: [ 'header', 'anotherStyle' ] },
                    {
                        table: {
                            body: [
                                [{text: '1', bold: true, style: 'tableHeader'}, {text: 'Reduction in Shrinkage', bold: true, style: 'tableHeader'}, {text: this.reduction_in_shrinkage+'%', bold: true, style: 'tableHeader'}],
                                ['', 'Reduction in Shoplifting', this.reduction_in_shoplifting+'%'],
                                ['', 'Reduction in Employee theft', this.reduction_in_employee_theft+'%'],
                                ['', 'Reduction in Paperwork errors', this.reduction_in_paperwork_theft+'%'],
                                ['', 'Reduction in Supplier fraud', this.reduction_in_supplier_fraud+'%'],
                                ['', 'Reduction in Others', this.reduction_in_others+'%'],
                                ['', 'New Shrinkage(%ge of sales)', this.new_shrinkage_per_of_sales+'%'],
                                [{text: '2', bold: true, style: 'tableHeader'}, {text: 'Increase in Revenue/Sqft', bold: true, style: 'tableHeader'}, {text: this.increase_in_revenue_sqft+'%', bold: true, style: 'tableHeader'}],
                                [{text: '3', bold: true, style: 'tableHeader'}, {text: 'Reduction in Labour Hours', bold: true, style: 'tableHeader'}, {text: this.reduction_in_labour_hours+'%', bold: true, style: 'tableHeader'}],
                                ['', 'Reduction in Staff enquiry cost', this.reduction_in_staff_enquiry_cost+'%'],
                                ['', 'Reduction in Stock keeping time', this.reduction_in_stock_keeping_time+'%'],
                                ['', 'Reduction in security & surveillance cost', this.reduction_in_security_survelliance_cost+'%'],
                                [{text: '4', bold: true, style: 'tableHeader'}, {text: 'Increase in Inventory Turn over', bold: true, style: 'tableHeader'}, {text: this.reduction_in_inventory_turn_over+'%', bold: true, style: 'tableHeader'}],
                                ['', 'Reduction in Failed Sales', this.reduction_in_failed_sales+'%'],
                                ['', 'Leaner Inventory', this.reduction_in_leaner_inventory+'%'],
                                ['', 'Reduction in Obscelence Cost/Mark down cost', this.reduction_in_obscelence_cost_mark_down_cost+'%']
                            ]
                        }
                    },
                ],
                styles: {tableHeader: {bold: true,fontSize: 14,color: 'white',fillColor: '#1B426E',alignment: 'center'},
                header: {fontSize: 22,bold: true},
                anotherStyle: {italics: true, alignment: 'center'}
                }
            }
      if (this.plt.is('cordova')) {
            this.pdfObj = pdfMake.createPdf(docDefinition);
            this.pdfObj.getBuffer((buffer) => {
            var blob = new Blob([buffer], { type: 'application/pdf' });
            // Save the PDF to the data Directory of our App
            this.file.writeFile(this.file.dataDirectory, 'RFID-ROI-ESTIMATOR.pdf', blob, { replace: true }).then(fileEntry => {
              // Open the PDf with the correct OS tools
              this.fileOpener.open(this.file.dataDirectory + 'RFID-ROI-ESTIMATOR.pdf', 'application/pdf');
            })
          });
        } else {
           this.pdfObj = pdfMake.createPdf(docDefinition).download('RFID-ROI-ESTIMATOR.pdf');
        }
      }
    
    sendEmail(){
        var docDefinition = {
          content: [
                    { text: 'Dashboard', style: [ 'header', 'anotherStyle' ] },
                    {
                        table: {
                            body: [
                                 [{text: '', bold: true, style: 'tableHeader'}, {text: '(in '+ this.currency_preference+')', bold: true, style: 'tableHeader'}, {text: '(in INR) 1 '+ this.currency_preference+' = INR '+ this.other_currency_to_inr, bold: true, style: 'tableHeader'}],
                                ['Total cost of implementation/Store', this.total_cost_of_implementation_store_other_currency, this.total_cost_of_implementation_store_in_inr],
                                ['Recurring cost/Year', this.recurring_cost_per_year_other_currency, this.recurring_cost_per_year_in_inr],
                                ['Chain wide investment for the period of 3 years', this.total_chain_wide_investment_other_currency, this.total_chain_wide_investment_in_inr],
                                ['Chain wide Net Benefits for the period of 3 years', this.total_chain_wide_net_benefits_other_currency, this.total_chain_wide_net_benefits_in_inr],
                                ['Payback(in Months)', this.payback_period_in_months, this.payback_period_in_months],
                            ]
                        }
                    },
                    { text: 'Benefits of RFID Solutions', style: [ 'header', 'anotherStyle' ] },
                    {
                        table: {
                            body: [
                                [{text: '1', bold: true, style: 'tableHeader'}, {text: 'Reduction in Shrinkage', bold: true, style: 'tableHeader'}, {text: this.reduction_in_shrinkage+'%', bold: true, style: 'tableHeader'}],
                                ['', 'Reduction in Shoplifting', this.reduction_in_shoplifting+'%'],
                                ['', 'Reduction in Employee theft', this.reduction_in_employee_theft+'%'],
                                ['', 'Reduction in Paperwork errors', this.reduction_in_paperwork_theft+'%'],
                                ['', 'Reduction in Supplier fraud', this.reduction_in_supplier_fraud+'%'],
                                ['', 'Reduction in Others', this.reduction_in_others+'%'],
                                ['', 'New Shrinkage(%ge of sales)', this.new_shrinkage_per_of_sales+'%'],
                                [{text: '2', bold: true, style: 'tableHeader'}, {text: 'Increase in Revenue/Sqft', bold: true, style: 'tableHeader'}, {text: this.increase_in_revenue_sqft+'%', bold: true, style: 'tableHeader'}],
                                [{text: '3', bold: true, style: 'tableHeader'}, {text: 'Reduction in Labour Hours', bold: true, style: 'tableHeader'}, {text: this.reduction_in_labour_hours+'%', bold: true, style: 'tableHeader'}],
                                ['', 'Reduction in Staff enquiry cost', this.reduction_in_staff_enquiry_cost+'%'],
                                ['', 'Reduction in Stock keeping time', this.reduction_in_stock_keeping_time+'%'],
                                ['', 'Reduction in security & surveillance cost', this.reduction_in_security_survelliance_cost+'%'],
                                [{text: '4', bold: true, style: 'tableHeader'}, {text: 'Increase in Inventory Turn over', bold: true, style: 'tableHeader'}, {text: this.reduction_in_inventory_turn_over+'%', bold: true, style: 'tableHeader'}],
                                ['', 'Reduction in Failed Sales', this.reduction_in_failed_sales+'%'],
                                ['', 'Leaner Inventory', this.reduction_in_leaner_inventory+'%'],
                                ['', 'Reduction in Obscelence Cost/Mark down cost', this.reduction_in_obscelence_cost_mark_down_cost+'%']
                            ]
                        }
                    },
                ],
                styles: {tableHeader: {bold: true,fontSize: 14,color: 'white',fillColor: '#1B426E',alignment: 'center'}, 
                header: {fontSize: 22,bold: true},
                anotherStyle: {italics: true, alignment: 'center'}
                }
            }        
        
           if (this.plt.is('cordova')) {
                this.pdfObj = pdfMake.createPdf(docDefinition);
                this.pdfObj.getBuffer((buffer) => {
                var blob = new Blob([buffer], { type: 'application/pdf' });
                // Save the PDF to the data Directory of our App
                this.file.writeFile(this.file.dataDirectory, 'RFID-ROI-ESTIMATOR.pdf', blob, { replace: true });
                let email = {
                  to: 'vkthiru@gmail.com',
                  cc: 'vkthiru@gmail.com',
                  bcc: ['vkthiru@gmail.com'],
                  attachments: [this.file.dataDirectory+'/RFID-ROI-ESTIMATOR.pdf'],
                  subject: 'RFID-ROI Estimator',
                  body: 'How are you? Nice greetings from RFID-ROI Estimator',
                  isHtml: true
                }
                this.emailComposer.open(email);    
          });
        } else {           
           this.pdfObj = pdfMake.createPdf(docDefinition).download('RFID-ROI-ESTIMATOR.pdf');
           console.log(this.file.dataDirectory);
           let email = {
              to: 'vkthiru@gmail.com',
              cc: 'vkthiru@gmail.com',
              bcc: ['vkthiru@gmail.com'],
              attachments: [this.file.dataDirectory+'/RFID-ROI-ESTIMATOR.pdf'],
              subject: 'RFID-ROI Estimator',
              body: 'How are you? Nice greetings from RFID-ROI Estimator',
              isHtml: true
            }
            this.emailComposer.open(email);  
        }
    }
}
