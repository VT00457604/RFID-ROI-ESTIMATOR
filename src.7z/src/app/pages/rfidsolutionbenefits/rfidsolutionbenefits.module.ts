import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { IonicModule } from '@ionic/angular';

import { RfidsolutionbenefitsPage } from './rfidsolutionbenefits.page';

const routes: Routes = [
  {
    path: '',
    component: RfidsolutionbenefitsPage
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RouterModule.forChild(routes)
  ],
  declarations: [RfidsolutionbenefitsPage]
})
export class RfidsolutionbenefitsPageModule {}
