import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute} from "@angular/router";
import { NavController, Platform, IonSlides } from '@ionic/angular';
import { Routes, RouterModule,NavigationExtras  } from '@angular/router';
import * as HighCharts from 'highcharts';
//declare var require: any;
//var Highcharts = require('highcharts');
//require('highcharts/modules/exporting')(Highcharts);

import pdfMake from 'pdfmake/build/pdfmake';
import pdfFonts from 'pdfmake/build/vfs_fonts';
pdfMake.vfs = pdfFonts.pdfMake.vfs;
import { File } from '@ionic-native/file/ngx';
import { FileOpener } from '@ionic-native/file-opener/ngx';

import { EmailComposer } from '@ionic-native/email-composer/ngx';

import { LoadingController } from '@ionic/angular';
@Component({
  selector: 'app-assumptions',
  templateUrl: './assumptions.page.html',
  styleUrls: ['./assumptions.page.scss'],
})
export class AssumptionsPage implements OnInit {
    pdfObj = null;        
    currency_preference                         : any;
    total_number_of_items_to_be_tagged          : any;
    total_items_on_the_floor                    : any;
    total_items_in_the_back_room                : any;
    average_selling_price_per_item              : any;
    sold_items_number                           : any; 
    annual_revenue_per_store                    : any;
    size_of_store                               : any;
    number_of_stores                            : any;
    //tax_rate                                    : any;
    labor_cost_hour                             : any;
    hours_spent_per_store_month                 : any;
    no_of_items_on_the_floor                    : any;
    no_of_items_counted_per_person_store_hour   : any;
    back_to_front_replenishment                 : any;
    staff_enquiry_cost                          : any;
    staff_enquiry_time_to_sale_one_apparel      : any;
    security_surveillance_cost                  : any;
    inventory                                   : any;
    mark_down_percentage                        : any;
    failed_sales                                : any;    
    
    public shoplifting_current_status: string                   = '38';
    public shoplifting_solution_benefits: string                = '20';
    public shoplifting_desired_status: string                   = '30';
    
    public employee_theft_current_status: string                = '35';
    public employee_theft_solution_benefits: string             = '20';
    public employee_theft_desired_status: string                = '28';
    
    public paperwork_errors_current_status: string              = '16';
    public paperwork_errors_solution_benefits: string           = '60';
    public paperwork_errors_desired_status: string              = '6';
    
    public supplier_fraud_current_status: string                = '7';
    public supplier_fraud_solution_benefits: string             = '0';
    public supplier_fraud_desired_status: string                = '7';
    
    public others_current_status: string                        = '4';
    public others_solution_benefits: string                     = '0';
    public others_desired_status: string                        = '4';
    
    public total_shrinkage_current_status: string               = '2';
    public total_shrinkage_desired_status: string               = '0';
    
    public sales_increase_due_to_better_product_mix: string     = '2';
    public sales_increase_due_to_more_variants_omni_channel: string = '2';
    public sales_increase_due_to_ability_locate_stocks: string  = '1';
    
    
    myChart                                     : any;
    
    slideOpts1 = {
        initialSlide: 0,
        speed: 400,
        loop: true,
        slidesPerView: 1,
        autoplay: false
    };
  constructor(private route: ActivatedRoute,public navCtrl: NavController, private plt: Platform, private file: File, private fileOpener: FileOpener, private emailComposer: EmailComposer,public loadingController: LoadingController) { }

  ngOnInit(){
      this.loadingController.create({
            message: 'Estimating Almost Done!!!',
            duration: 1000
       }).then((res) => {
            res.present();
       });
       this.route.queryParams.subscribe(params => {
                this.currency_preference                         = params["currency_preference"];
                this.total_number_of_items_to_be_tagged          = params["total_number_of_items_to_be_tagged"];
                this.total_items_on_the_floor                    = params["total_items_on_the_floor"];
                this.total_items_in_the_back_room                = params["total_items_in_the_back_room"];
                this.average_selling_price_per_item              = params["average_selling_price_per_item"];
                this.sold_items_number                           = params["sold_items_number"];
                this.annual_revenue_per_store                    = params["annual_revenue_per_store"];
                this.size_of_store                               = params["size_of_store"];
                this.number_of_stores                            = params["number_of_stores"];
               // this.tax_rate                                  = params["tax_rate"];
                this.labor_cost_hour                             = params["labor_cost_hour"];
                this.hours_spent_per_store_month                 = params["hours_spent_per_store_month"];
                this.no_of_items_on_the_floor                    = params["no_of_items_on_the_floor"];
                this.no_of_items_counted_per_person_store_hour   = params["no_of_items_counted_per_person_store_hour"];
                this.back_to_front_replenishment                 = params["back_to_front_replenishment"];
                this.staff_enquiry_cost                          = params["staff_enquiry_cost"];
                this.staff_enquiry_time_to_sale_one_apparel      = params["staff_enquiry_time_to_sale_one_apparel"];
                this.security_surveillance_cost                  = params["security_surveillance_cost"];
                this.inventory                                   = params["inventory"];
                this.mark_down_percentage                        = params["mark_down_percentage"];
                this.failed_sales                                = params["failed_sales"];  
       });
     }
    viewBenefits() {
        let navigationExtras: NavigationExtras = {
            queryParams: {
                currency_preference                         : this.currency_preference,
                total_number_of_items_to_be_tagged          : this.total_number_of_items_to_be_tagged,
                total_items_on_the_floor                    : this.total_items_on_the_floor,
                total_items_in_the_back_room                : this.total_items_in_the_back_room,
                average_selling_price_per_item              : this.average_selling_price_per_item,
                sold_items_number                           : this.sold_items_number,
                annual_revenue_per_store                    : this.annual_revenue_per_store,
                size_of_store                               : this.size_of_store,
                number_of_stores                            : this.number_of_stores,
               // tax_rate                                  : this.tax_rate,
                labor_cost_hour                             : this.labor_cost_hour,
                hours_spent_per_store_month                 : this.hours_spent_per_store_month,
                no_of_items_on_the_floor                    : this.no_of_items_on_the_floor,
                no_of_items_counted_per_person_store_hour   : this.no_of_items_counted_per_person_store_hour,
                back_to_front_replenishment                 : this.back_to_front_replenishment,
                staff_enquiry_cost                          : this.staff_enquiry_cost,
                staff_enquiry_time_to_sale_one_apparel      : this.staff_enquiry_time_to_sale_one_apparel,
                security_surveillance_cost                  : this.security_surveillance_cost,
                inventory                                   : this.inventory,
                mark_down_percentage                        : this.mark_down_percentage,
                failed_sales                                : this.failed_sales,  
                shoplifting_current_status                  : this.shoplifting_current_status,
                shoplifting_solution_benefits               : this.shoplifting_solution_benefits,
                shoplifting_desired_status                  : this.shoplifting_desired_status,
                employee_theft_current_status               : this.employee_theft_current_status,
                employee_theft_solution_benefits            : this.employee_theft_solution_benefits,
                employee_theft_desired_status               : this.employee_theft_desired_status,
                paperwork_errors_current_status             : this.paperwork_errors_current_status,
                paperwork_errors_solution_benefits          : this.paperwork_errors_solution_benefits,
                paperwork_errors_desired_status             : this.paperwork_errors_desired_status,
                supplier_fraud_current_status               : this.supplier_fraud_current_status,
                supplier_fraud_solution_benefits            : this.supplier_fraud_solution_benefits,
                supplier_fraud_desired_status               : this.supplier_fraud_desired_status,
                others_current_status                       : this.others_current_status,
                others_solution_benefits                    : this.others_solution_benefits,
                others_desired_status                       : this.others_desired_status,
                total_shrinkage_current_status              : this.total_shrinkage_current_status,
                total_shrinkage_desired_status              : this.total_shrinkage_desired_status,
                sales_increase_due_to_better_product_mix    : this.sales_increase_due_to_better_product_mix,
                sales_increase_due_to_more_variants_omni_channel: this.sales_increase_due_to_more_variants_omni_channel,
                sales_increase_due_to_ability_locate_stocks : this.sales_increase_due_to_ability_locate_stocks
            }
        };
        this.navCtrl.navigateForward(['rfidsolutionbenefits'], navigationExtras);
   }
   
    
}
